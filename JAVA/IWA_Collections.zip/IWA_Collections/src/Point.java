import java.util.*; 
class Point {
    private int x,y;
    Point (int x, int y) {
       this.x=x;  this.y=y;
    }
    public int hashCode () {
	      return x+y;
    	//return (new Random()).nextInt();
    }
    public boolean equals (Object pp) {
          Point p = (Point) pp;
          return ((this.x == p.x) & (this.y == p.y));
    }
    public String toString() {
          return "[" + x + " " + y + "]";
   }
}