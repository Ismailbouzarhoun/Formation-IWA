import java.util.*;
public class Tri {
    public static void main(String[] args) {
    int nb [] = {4,5,2,1,6,8,3};
    ArrayList t = new ArrayList();
        for (int i=0;i<nb.length;i++) t.add(new Integer(nb[i]));
        System.out.println("t initial="+t);
	
        Collections.sort(t);
        System.out.println("t trié="+t);
		
        Collections.shuffle(t);
        System.out.println("t mélangé="+t);
		
        Collections.sort(t, Collections.reverseOrder()); // un comparateur prédéfini
        System.out.println("t trié="+t);	
    }
}