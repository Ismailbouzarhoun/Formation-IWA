import java.util.*;

public class Employe {
     int id;
     int salaire ;
     Employe (int i, int s){
        id = i;
        salaire =s;
     }
     void imprimer(){
         System.out.println("Employe "+id +" salaire "+salaire);
     }
     public String toString(){
         return "Employer :"+id+" salaire "+salaire;
     }
}