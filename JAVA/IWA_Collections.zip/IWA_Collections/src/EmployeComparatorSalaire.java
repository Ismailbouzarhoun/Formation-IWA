import java.util.Comparator;
class EmployeComparatorSalaire implements Comparator{
    public int compare (Object o1, Object o2){
      if ((((Employe)(o1)).salaire) < (((Employe)(o2)).salaire)) return -1;
      else if ((((Employe)(o1)).salaire) > (((Employe)(o2)).salaire)) return 1;
        else return 0;
    }
}