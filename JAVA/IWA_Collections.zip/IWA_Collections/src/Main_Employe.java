import java.util.*;
class Main_Employe {
    public static void main(String[] args) {
        ArrayList c= new ArrayList();
        Random r= new Random();
        for (int i=0;i<10;i++) c.add(new Employe(i,r.nextInt(5000)));
        for(int i=0; i<c.size();i++) System.out.println(i + " " +c.get(i));

        Comparator comp = new EmployeComparatorSalaire();
        System.out.println("max " + Collections.max(c,comp));
        Collections.sort(c,comp);
        for(int i=0; i<c.size();i++)
        System.out.println(i + " " + c.get(i));
	
   }
}