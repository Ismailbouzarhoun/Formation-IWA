import java.util.*;

public class EmployeC implements Comparable{
         int id;
         EmployeC (int i){
             id = i;
        }
        public int compareTo(Object o) {
               if ((this.id) < (((EmployeC)(o)).id))
                      return -1;
               else if ((this.id) > (((EmployeC)(o)).id))
                        return 1;
                     else
                        return 0;
       }
       void imprimer(){
                System.out.println("EmployeC "+id);
       }
       public String toString(){
                  return "EmployeC :"+id;
       }
}